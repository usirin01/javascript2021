/**
 * 
 */



let btnLogin = document.querySelector("#login");
btnLogin.addEventListener("click", function(event){

    const name = document.querySelector("name");
    const password = document.querySelector("password");
   
    alert("correct");

})
